import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GradeBook book = new GradeBook();
        boolean running = true;

        while (running) {
            System.out.println("\n=== СИСТЕМА АНАЛИЗА ОЦЕНОК ===");
            System.out.println("1. Показать всех студентов");
            System.out.println("2. Добавить студента");
            System.out.println("3. Найти студента по имени");
            System.out.println("4. Средние баллы студентов");
            System.out.println("5. Рейтинг студентов");
            System.out.println("6. Статистика группы");
            System.out.println("0. Выход");
            System.out.print("Выбор: ");
            String input = scanner.nextLine();

            switch (input) {
                case "1" -> book.printAll();
                case "2" -> {
                    System.out.print("Имя: ");
                    String name = scanner.nextLine().trim();
                    int[] grades = new int[3];
                    boolean valid = true;
                    for (int i = 0; i < grades.length; i++) {
                        System.out.print("Оценка " + (i + 1) + " (0-100): ");
                        try {
                            grades[i] = Integer.parseInt(scanner.nextLine().trim());
                        } catch (NumberFormatException e) {
                            valid = false;
                            break;
                        }
                    }
                    if (!valid) System.out.println("Ошибка: оценки должны быть числами.");
                    else System.out.println(book.addStudent(name, grades) ? "Добавлено." : "Не удалось добавить студента.");
                }
                case "3" -> {
                    System.out.print("Имя для поиска: ");
                    int index = book.findByName(scanner.nextLine());
                    if (index == -1) System.out.println("Студент не найден.");
                    else book.printStudent(index);
                }
                case "4" -> book.printAverages();
                case "5" -> book.printRanking();
                case "6" -> book.printStatistics();
                case "0" -> running = false;
                default -> System.out.println("Неизвестная команда.");
            }
        }
        scanner.close();
    }
}
