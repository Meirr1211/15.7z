public class GradeBook {
    private static final int CAPACITY = 12;
    private final String[] names = new String[CAPACITY];
    private final int[][] grades = new int[CAPACITY][3];
    private int count = 0;

    public GradeBook() {
        addStudent("Aruzhan", new int[]{90, 80, 70});
        addStudent("Dias", new int[]{60, 75, 90});
        addStudent("Madina", new int[]{100, 95, 90});
        addStudent("Alibek", new int[]{55, 65, 75});
    }

    public boolean addStudent(String name, int[] values) {
        if (count >= CAPACITY || name == null || name.isBlank() || values == null || values.length != 3) return false;
        for (int grade : values) {
            if (grade < 0 || grade > 100) return false;
        }
        name = name.trim();
        if (findByName(name) != -1) return false;
        names[count] = name;
        grades[count] = values.clone();
        count++;
        return true;
    }

    public int findByName(String query) {
        if (query == null) return -1;
        String q = query.trim();
        for (int i = 0; i < count; i++) {
            if (names[i].equalsIgnoreCase(q)) return i;
        }
        return -1;
    }

    public double average(int index) {
        int sum = 0;
        for (int value : grades[index]) sum += value;
        return (double) sum / grades[index].length;
    }

    public void printStudent(int index) {
        System.out.printf("%s: [%d, %d, %d], средний балл: %.2f%n",
                names[index], grades[index][0], grades[index][1], grades[index][2], average(index));
    }

    public void printAll() {
        for (int i = 0; i < count; i++) printStudent(i);
    }

    public void printAverages() {
        for (int i = 0; i < count; i++) {
            System.out.printf("%s: %.2f%n", names[i], average(i));
        }
    }

    public void printRanking() {
        int[] order = new int[count];
        for (int i = 0; i < count; i++) order[i] = i;
        for (int i = 0; i < count; i++) {
            for (int j = i + 1; j < count; j++) {
                if (average(order[i]) < average(order[j])) {
                    int temp = order[i];
                    order[i] = order[j];
                    order[j] = temp;
                }
            }
        }
        for (int i = 0; i < count; i++) {
            System.out.printf("%d. %s (%.2f)%n", i + 1, names[order[i]], average(order[i]));
        }
    }

    public void printStatistics() {
        if (count == 0) return;
        double min = Double.POSITIVE_INFINITY;
        double max = Double.NEGATIVE_INFINITY;
        int passed = 0;
        double total = 0;
        for (int i = 0; i < count; i++) {
            double avg = average(i);
            total += avg;
            if (avg < min) min = avg;
            if (avg > max) max = avg;
            if (avg >= 60) passed++;
        }
        System.out.printf("Средний балл группы: %.2f%n", total / count);
        System.out.printf("Минимальный средний: %.2f, максимальный: %.2f%n", min, max);
        System.out.println("Студентов со средним баллом >= 60: " + passed);
    }
}
